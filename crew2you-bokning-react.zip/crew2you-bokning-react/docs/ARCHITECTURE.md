# Architecture

Beslut tagna och varför, så vi (eller framtida utvecklare) inte behöver gissa senare.

---

## 1. Multitenant från dag 1

**Beslut:** Alla tabeller har `org_id`. RLS policies isolerar data per org.

**Varför:** Crew2you är första kunden men vi vet att vi vill sälja systemet till andra bemanningsfirmor. Att refactora från single-tenant till multi-tenant senare är en månads jobb och 100% buggar. Att bygga rätt från start är en timmes extra arbete.

**Konsekvens:** Varje insert måste sätta `org_id`. Varje query filtreras automatiskt av RLS. Joins går alltid via tenant först.

---

## 2. Roller som Postgres ENUM, inte JSON

**Beslut:** `user_role` är ett ENUM-typ i databasen.

**Varför:** Type-safety från databas till UI. ENUM-värden kan inte stavas fel. RLS policies kan jämföra direkt utan parsning.

**Trade-off:** Att lägga till ny roll kräver migration (`ALTER TYPE`). Det är medvetet — roller bör ändras sällan och eftertänksamt.

---

## 3. Soft delete (`deleted_at`) istället för hard delete

**Beslut:** Inga `DELETE FROM`. Allt är `UPDATE SET deleted_at = now()`.

**Varför:** Användare ångrar sig. Bokföring kräver ofta historik. Kunder kan tvista om vad som faktiskt fanns. Soft delete = återställbart, hard delete = kundförlust.

**Konsekvens:** Alla `SELECT` måste filtrera `WHERE deleted_at IS NULL`. Index lagts på `WHERE deleted_at IS NULL` för att inte tappa prestanda.

---

## 4. Audit log på allt

**Beslut:** Tabell `audit_log` med `actor_id`, `action`, `entity_type`, `entity_id`, `changes`, `ip`.

**Varför:** "Vem flyttade min bokning?", "När ändrades priset?", "Loggade Adnan in på vår data?" — alla blir frågor förr eller senare. GDPR kräver också ofta access logs.

**Konsekvens:** Edge Functions och triggers skriver dit. Litet performance-overhead, stort värde.

---

## 5. React Query för server state, Zustand för UI state

**Beslut:** Inte Redux. Inte Context. **TanStack Query** för allt som kommer från Supabase. **Zustand** för UI-prefs och auth.

**Varför:** Server state och UI state är olika problem. React Query löser caching, optimistic updates, retries, refetching utan konfiguration. Zustand är minimalt och funkar för det lilla UI-state-laget.

**Konsekvens:** Inga useEffect-träsken. Varje server-resurs har en hook (`useBookings`, `useCustomer(id)`).

---

## 6. Edge Functions för all server-side logik

**Beslut:** AI-anrop, Fortnox-anrop, mailutskick, SMS — allt går via Supabase Edge Functions.

**Varför:** API-nycklar får aldrig hamna i klienten. Edge Functions kör nära databasen (eu-north-1). Webhook-mottagning (Resend Inbound, Fortnox callbacks) behöver också serverless endpoints.

**Konsekvens:** Klienten anropar `supabase.functions.invoke('ai-parse-email', ...)`. Funktionen kör med service role key och kan göra vad som helst i databasen utan RLS.

---

## 7. Inga klassiska forms (`<form>`-tags) — allt med React Hook Form + Zod

**Beslut:** Validering med Zod-scheman. Forms via RHF.

**Varför:** Zod-scheman = en sanning för validering på klient + Edge Function (samma schema används). Type inference blir 100% rätt. RHF är lätt och har minimal re-render.

**Konsekvens:** Lägg form-scheman i `src/lib/schemas/`. Återanvänd i både UI och edge functions.

---

## 8. Ingen automatisk drag-and-drop i fas 1

**Beslut:** Pipeline har "Flytta till nästa steg"-knapp i fas 1, drag-and-drop i fas 2+.

**Varför:** Drag-and-drop på touch-enheter är fortfarande klurigt. Knapp-baserad flytt är mer förutsägbar och fungerar identiskt på mobil och desktop. Lägger till drag-and-drop som progressive enhancement senare.

---

## 9. Single org per user (för nu)

**Beslut:** En user_profile per user, en org per profile.

**Varför:** Carina jobbar bara på Crew2you. Adnan/Rasmus är `super_admin` som kan impersonate andra orgs. Inte värt komplexiteten av att en användare hör till flera orgs samtidigt.

**Trade-off:** Om Crew2you någonsin köper upp ett annat bolag som också använder oss måste det merge:as. Sannolikt: aldrig.

---

## 10. Magic link för auth, inget password

**Beslut:** Supabase Auth med OTP via mail. Inga lösenord någonstans.

**Varför:** Demovärdar glömmer lösenord. Magic link = klick i mail = inloggad. Säkrare också (inga password breaches möjliga). Stöd för password kan läggas till senare om Carina specifikt vill ha det.

---

## 11. Snapshot-fält i `bookings` (`store_name`, `customer_name`)

**Beslut:** Bookings har både `store_id`-relation **och** `store_name`-text.

**Varför:** Om en butik raderas eller byter namn ska gamla bokningar fortfarande visa "Hemköp Wasahallen 2026-01-15" — inte "Okänd butik". Snapshot vid skapande gör historiken oföränderlig.

**Konsekvens:** När butik ändras uppdateras inte gamla bokningar automatiskt. Det är poängen.

---

## Sammanfattning

Stack: React + TS + Supabase + Tailwind + React Query + Zustand + Edge Functions.

Principer: Multitenant, soft delete, RLS, audit log, type-safe från DB till UI, server state separat från UI state.

Inget av det här är dyrt att göra rätt från start. Allt är dyrt att göra om senare.
