# Claude Code Prompts — Crew2you Bygg-pipeline

Färdiga prompts att köra i Claude Code (kör i terminalen i repots root: `claude` eller `cc`).

**Hur du använder dem:**

1. Kör prompts i ordning — varje fas bygger på den förra
2. Mellan varje prompt: kontrollera resultatet, commita, pusha
3. Om något går fel: stanna, förklara för Claude vad som blev fel, be om fix
4. Säg aldrig "fortsätt med nästa fas" innan föregående är testad

**Tips:**

- Claude Code är bättre när du säger vad du **inte** vill (t.ex. "skapa inte nya filer som inte är listade här")
- Be Claude köra `npm run typecheck` och `npm run lint` efter varje större ändring
- När en feature är klar, be Claude skriva en kort commit-message i imperative form

---

## PROMPT 0 — Verifiera att grunden funkar (5 min)

Kör först av allt:

```
Innan vi börjar bygga features vill jag verifiera att grunden fungerar:

1. Kör `npm install`
2. Kör `npm run typecheck` — rapportera om det är några fel
3. Kör `npm run build` — rapportera om det byggs korrekt
4. Lista alla filer i src/ så jag ser vad som finns

Om allt är grönt: säg till. Annars fixa felen och berätta vad du gjorde.

Jag har INTE satt upp Supabase än — så att appen inte startar med dev-servern är förväntat. Bara verifiera att TypeScript och bygget fungerar.
```

---

## PROMPT 1 — Sätt upp Supabase och verifiera

```
Hjälp mig sätta upp Supabase. Förutsättningar:

- Jag har skapat ett Supabase-projekt i regionen eu-north-1 (Stockholm)
- Project ref: [SÄTT IN HÄR]
- Anon key: [SÄTT IN HÄR]
- Service role key: [SÄTT IN HÄR — finns i Project Settings → API]

Gör följande:

1. Skapa en .env-fil från .env.example med rätt VITE_SUPABASE_URL och VITE_SUPABASE_ANON_KEY
2. Installera supabase CLI globalt om det inte redan är installerat: `npm install -g supabase`
3. Logga in: `supabase login` (säg till mig att jag måste göra detta interaktivt i terminalen)
4. Länka projektet: `supabase link --project-ref [REF]`
5. Pusha alla migrations: `supabase db push`
6. Generera typer: `supabase gen types typescript --project-id [REF] > src/types/database.ts`
7. Verifiera att typerna är genererade och att `npm run typecheck` fortfarande passerar

Skapa två test-användare via Supabase Auth API:
- adnan@samify.se (denna får automatiskt super_admin via triggern)
- carina@crew2you.se (denna får org_user, men uppdatera till org_admin med en SQL-update efter)

Verifiera i Supabase Studio att:
- Alla tabeller finns
- RLS är aktiverat på alla
- 9 default automations finns för Crew2you-orgen
- user_profiles har 2 rader

Säg till om något krånglar.
```

---

## PROMPT 2 — Hooks för data fetching (Phase 1 - foundation)

```
Bygg TanStack Query-hooks för all data åtkomst. Skapa filer i src/hooks/:

- useBookings.ts — listar bokningar med filter (stage, region, search)
- useBooking.ts — enskild bokning med relationer
- usePersonnel.ts — listar personal
- usePerson.ts — enskild person
- useCustomers.ts — listar kunder med kontakter
- useCustomer.ts — enskild kund
- useStores.ts — listar butiker med kontakter
- useStore.ts — enskild butik
- useExpenses.ts — utlägg (filter på personnel_id eller booking_id)
- useAutomations.ts — listar automationer
- useAutomationRuns.ts — körningshistorik

Varje hook ska:
- Använda useQuery med rätt cache-key (`['bookings', filters]`)
- Hantera loading och error
- Returnera typade data från Database-typerna

Lägg också till mutations i samma filer:
- useCreateBooking, useUpdateBooking, useAdvanceBookingStage
- useCreatePersonnel, useUpdatePersonnel
- useCreateExpense
- etc.

Mutations ska invalidera relevanta queries via queryClient.invalidateQueries.

Skriv inte UI än — bara hooks. Kör `npm run typecheck` när klart.
```

---

## PROMPT 3 — Pipeline-vyn (Phase 1 - core feature)

```
Bygg pipeline-vyn — den 7-stegs kanban som ersätter Excel-kolumnerna.

Skapa:
- src/pages/admin/PipelinePage.tsx — main page
- src/components/bookings/PipelineColumn.tsx — en kolumn per stage
- src/components/bookings/BookingCard.tsx — ett kort per bokning
- src/components/bookings/BookingDetailModal.tsx — full detalj-vy

Stages: inkommen, bokad, bekraftad, personal, genomford, aterrapporterad, fakturerad

Funktionalitet:
- 7 kolumner sida vid sida (horizontal scroll på små skärmar)
- Varje kolumn har header med stage-namn, färgindikator-prick, count
- Bookings-kort visar: butik, ort, dagar, kund, tjänst-chip, antal timmar, personal (eller "Saknar personal" i rött)
- Sökruta som filtrerar fritextsök
- Region-dropdown som filtrerar
- Klick på kort öppnar BookingDetailModal med all info + stage timeline + "Flytta till nästa steg"-knapp
- Ingen drag-and-drop i denna fas — bara knapp-baserad förflyttning

Använd hookarna från prompt 2. Använd Tailwind-tokens (gold, ink, surface, status-färger). Se /home/claude/crew2you/crew2you-bokning-demo.html för exakt hur det såg ut i demot — matcha designen 1:1.

Lägg till routen `/admin/pipeline` i App.tsx.

Verifiera: npm run typecheck, npm run lint. Säg till om något känns oklart i designen.
```

---

## PROMPT 4 — Bookings-tabellvy + Skapa nytt uppdrag (Phase 1)

```
Bygg två saker:

1. **BookingsTablePage** (src/pages/admin/BookingsPage.tsx) — tabellvy med alla bokningar:
   - Sökfält + status-filter
   - Kolumner: Datum, Butik, Ort, Kund, Tjänst, Personal, Tim, Status, Action
   - Klickbar rad öppnar BookingDetailModal (samma som i Pipeline)

2. **NewBookingModal** (src/components/bookings/NewBookingModal.tsx) — formulär för nytt uppdrag:
   - Använd React Hook Form + Zod-validation
   - Schema i src/lib/schemas/booking.ts
   - Fält: butik (dropdown från BUTIKER + "Ny butik"), kontaktperson (dropdown beroende på butik), tel, ort, region (auto-gissas från ort), datum, timmar, kund (dropdown), tjänst, personal (dropdown), produkt, material, info
   - Autofyll: när butik väljs → fyll ort/region/kontakt/tel
   - Autofyll: när kund väljs → fyll kund-fältet med "Kundnamn / Primärkontakt"
   - Smart suggestion: om butik+kund kombineras letar systemet i historiska bokningar och visar "Återanvänd uppgifter"-knapp
   - Visuella indikatorer (gulddot) bredvid fält som autofyllts
   - Knappar: Spara utkast (status: inkommen) + Spara & boka (status: bokad)

Lägg till "Nytt uppdrag"-knapp i topbar på alla admin-sidor.

Lägg till routen `/admin/bookings` i App.tsx.

Använd hookarna useCreateBooking. Verifiera typecheck och lint.
```

---

## PROMPT 5 — Personal-, kund- och butiksregister (Phase 1)

```
Bygg tre register-sidor:

1. **PersonnelPage** (src/pages/admin/PersonnelPage.tsx)
   - 4 KPI-kort högst upp (Totalt, Snittbetyg, Total erfarenhet, Uppdrag utförda)
   - Grid av personalkort (3 kolumner desktop, 1 mobil)
   - Varje kort: avatar (initialer), namn, hemort, betyg som stjärnor, kompetens-chips, specialitet-chips, aktiva uppdrag, reseradie
   - Klick → PersonnelProfileModal med full profil + uppdragshistorik
   - "Ny person"-knapp i topbar

2. **CustomersPage** (src/pages/admin/CustomersPage.tsx)
   - Två sektioner: "Uppdragsgivare" och "Butiker / platser"
   - Tabellrader med multi-kontakter visade kompakt under huvudraden
   - Varje kontaktkort visar avatar, namn, roll, telefon, mail, primary-badge
   - Klick på kontakt → öppnar tel:/mailto:
   - "Ny kund" och "Ny butik"-knappar

3. **PersonnelProfileModal** (src/components/personnel/PersonnelProfileModal.tsx)
   - Full profil med alla fält från personnel-tabellen
   - Uppdragshistorik (sista 6) i tabell
   - "Redigera profil"-knapp som öppnar PersonnelEditModal

Använd hookarna usePersonnel, useCustomers, useStores.

Routes: /admin/personnel, /admin/customers

Använd Lucide-ikoner och Tailwind. Matcha designen från demot exakt.
```

---

## PROMPT 6 — Personal-app (mobilvy) (Phase 1)

```
Bygg personalappen — mobilvyn för demovärdar.

Sidor (alla i src/pages/personal/):
- AssignmentsPage.tsx — "Mina uppdrag"-tab
- ExpensesPage.tsx — "Utlägg"-tab
- ReportsPage.tsx — "Återrapport"-tab

I PersonalLayout.tsx finns redan tabs.

**AssignmentsPage:**
- Lista över personens kommande uppdrag
- Varje kort visar: dagar (i mörk badge), butik, ort, timmar, kund, produkt, material, info
- Knappar längst ner: "+ Utlägg" (växlar till ExpensesPage), "Rapportera" (växlar till ReportsPage)
- Använd hooken useBookings filtrerad på personnel_id = profile.id

**ExpensesPage:**
- Toppkort: "Mina utlägg denna månad" — totalbelopp i guld
- "Registrera nytt utlägg"-knapp som öppnar NewExpenseModal
- Lista över historiska utlägg
- NewExpenseModal: dropdown med personens uppdrag, typ, belopp, beskrivning, foto-upload till Supabase Storage bucket "receipts"

**ReportsPage:**
- Lista över genomförda uppdrag som inte rapporterats
- Inline-formulär per uppdrag: hur gick demot, såld volym, faktiska timmar, foto från demon (upload till bucket "reports")
- "Skicka återrapport"-knapp → markerar booking.stage = 'aterrapporterad', uppdaterar fält

Använd useBookings, useCreateExpense, useUpdateBooking. Foto-upload via supabase.storage.from('receipts').upload().

Verifiera typecheck och att alla mutations invalidaterar rätt queries.
```

---

## PROMPT 7 — Kundportal basic (Phase 1)

```
Bygg kundportalen — vad uppdragsgivaren ser när hen loggar in.

Sidor i src/pages/kund/:
- KundOverviewPage.tsx — "Översikt"
- KundBookingsPage.tsx — "Mina bokningar"

**KundOverviewPage:**
- Kund-hero med "Hej [förnamn]" och översikt
- 4 KPI-kort: Kommande uppdrag, Genomförda, Totala timmar, Öppna fakturor
- Lista över kommande bokningar (samma som i admin men utan känslig info som faktura/lön)

**KundBookingsPage:**
- Tabell över alla kundens bokningar
- Filtrerbar på status

Använd RLS — useBookings i kund-kontext returnerar bara bokningar där customer_id matchar customers.user_id = current_user.id (RLS-policyn fixar detta automatiskt).

Återrapporter och fakturor lämnas till Phase 2 och 3. Lägg till placeholder-sidor för dem som säger "Kommer i nästa fas".
```

---

## PROMPT 8 — Faktura- och löneunderlag (Phase 1 sista bit)

```
Bygg två sidor för admin:

1. **InvoicesPage** (src/pages/admin/InvoicesPage.tsx) — Fakturaunderlag
2. **PayrollPage** (src/pages/admin/PayrollPage.tsx) — Löneunderlag

**InvoicesPage:**
- Sammanfattning högst upp (gulden box):
  - Klara att fakturera: X uppdrag
  - Timpris: 495 kr/h (från org settings)
  - Total arbetskostnad
  - Total utlägg
  - Summa att fakturera
- Tabell över bokningar med stage = 'aterrapporterad': Datum, Butik, Kund, Timmar, Arbete, Utlägg, Total
- "Exportera CSV"-knapp som genererar fil
- "Skicka till Fortnox"-knapp (placeholder för Phase 3)
- Sekundär tabell: Redan fakturerade

**PayrollPage:**
- Sammanfattning: Timlön: 180 kr/h, Total lön, Total utlägg, Total utbetalning
- Tabell per person: Person, Uppdrag, Timmar, Lön, Utlägg, Total
- "Exportera löneunderlag"-knapp (CSV i denna fas, SIE i Phase 3)

Routes: /admin/invoices, /admin/payroll.

Detta avslutar Phase 1. Verifiera att hela appen fungerar end-to-end:
- Carina kan logga in
- Skapa bokning
- Tilldela personal
- Personalen loggar in i mobilvyn, ser uppdraget, registrerar utlägg, skickar återrapport
- Carina ser fakturaunderlag

Driftsätt till Netlify enligt docs/DEPLOYMENT.md. Säg till mig när Phase 1 är driftsatt.
```

---

## PROMPT 9 — Autoflow Engine + Resend + 46elks (Phase 2)

```
Nu börjar vi Phase 2 — automationer. Mål: kontoret slutar manuellt skicka mail/SMS.

Bygg:

1. **Edge Function `automation-trigger`** (supabase/functions/automation-trigger/index.ts):
   - Tar emot event payload (event_type + entity data)
   - Slår upp aktiva automations för orgen som lyssnar på det event_typet
   - Kör actions sekventiellt
   - Loggar varje run i automation_runs

2. **Edge Function `send-email`** (supabase/functions/send-email/index.ts):
   - Använder Resend API
   - Tar template-namn + variables + recipient
   - Templates lagras som funktioner i src/lib/email-templates/ (genererar HTML)

3. **Edge Function `send-sms`** (supabase/functions/send-sms/index.ts):
   - Använder 46elks API
   - Format: kort, max 160 tecken

4. **Edge Function `send-calendar-invite`** (supabase/functions/send-calendar-invite/index.ts):
   - Genererar .ics-fil med uppdragets datum/tid/plats
   - Bifogar till mail via Resend

5. **Trigger setup i Supabase**:
   - Database webhook på `bookings`-tabellen som POST:ar till automation-trigger när stage ändras
   - Trigger på `expenses` som postar `expense.created`
   - Cronjob (pg_cron) som kollar varje timme efter bokningar 24h fram → trigga `booking.reminder.24h`

6. **UI-komponent AutomationsPage** (src/pages/admin/AutomationsPage.tsx):
   - Hero med stats (X aktiva flöden, totala runs, sparad tid)
   - Grid av automation-kort med toggle on/off
   - Varje kort visar: namn, beskrivning, trigger → actions, runs, last_run, toggle
   - Körningslogg-sektion längst ner med ACTIVITY_LOG som timeline

Använd useAutomations + useAutomationRuns. Toggle-mutation som uppdaterar enabled-fältet.

Lägg till test: skapa bokning, flytta till bekraftad, verifiera att mail går ut.
```

---

## PROMPT 10 — AI-mailparsning (Phase 2)

```
Bygg AI-mailparsningen så Crew2you slipper manuellt registrera inkomna bokningsmail.

Komponenter:

1. **Resend Inbound webhook** → **Edge Function `ai-parse-email`** (supabase/functions/ai-parse-email/index.ts):
   - Tar emot inkommande mail från Resend (multipart payload med from, subject, text, html)
   - Sparar rådata i inbox_emails-tabellen
   - Anropar Anthropic API (Claude Sonnet 4.6) med en system-prompt som ber den extrahera:
     - butik, ort, kontakt, tel, dagar/tid, antal timmar, kund, tjänst, produkt, material, övrig info
   - För varje fält: confidence "high"/"medium"/"low"
   - Identifierar saknade fält (t.ex. "saknar konkret datum")
   - Sparar parsed_data i samma rad
   - Om alla obligatoriska fält är complete (high confidence): sätt parse_status = 'complete'
   - Annars: 'partial' eller 'incomplete' baserat på allvarlighet

2. **System prompt** för Claude — lägg i src/lib/ai-prompts.ts. Var explicit:
   - Returnera JSON enligt strikt schema
   - Använd Zod för att validera svaret
   - Markera osäkerhet hellre än att gissa fel

3. **UI: InboxPage** (src/pages/admin/InboxPage.tsx):
   - Lista över alla inbox_emails sorterade på received_at desc
   - Varje rad: avatar (initialer), från, ämne, preview, status-chip, antal saknade fält
   - Klick → EmailDetailModal med split view: original mail + AI-parsade fält
   - För complete: knapp "Skapa bokning" → skapar booking från parsed_data, sätter parse_status = 'booked'
   - För partial/incomplete: knapp "Skicka kompletteringsmail" → genererar AI-svar med saknade frågor, skickar via Resend, sparar auto_reply_sent_at

4. **Auto-reply-generering**:
   - Edge Function eller del av ai-parse-email
   - Anropar Claude med "Skriv ett professionellt svensk affärsmail som ber om följande saknade uppgifter: [lista]"
   - Sparar förhandsgranskning, kräver godkännande från admin innan utskick (eller auto-skicka om automation a9 är aktiverad)

5. **När kunden svarar**: ny inbound mail kommer in, ai-parse körs igen, slå ihop med original via threading (samma subject prefix "Re:")

Routes: /admin/inbox. Lägg till nav-länk i Sidebar.

Test: skicka ett testmail till bokning@crew2you.se, verifiera att det dyker upp parsat.
```

---

## PROMPT 11 — AI-matchning av personal (Phase 2)

```
Bygg AI-matchningen som föreslår topp 3 demovärdar till uppdrag som saknar personal.

Komponenter:

1. **Edge Function `ai-match-personnel`** (supabase/functions/ai-match-personnel/index.ts):
   - Input: booking_id
   - Hämtar bookingen + butik (med koordinater) + alla aktiva personnel i samma org
   - För varje person, beräkna matchscore:
     - Geografi (haversine-formel mellan personnens hemort och butikens koordinater): max 35 poäng
     - Reseradie: blockerar om utanför max_radius_km
     - Kompetens: 25 poäng om de har bookingens service_type, annars block
     - Tidigare uppdrag hos samma kund: max 18 poäng (6 per uppdrag, capped at 18)
     - Specialitet match mot produkt/material: 12 poäng
     - Betyg 4.0+: bonus upp till 15 poäng
     - Konflikt-check: filtrera bort om redan bokad samma dagar/datum
   - Returnera sorterad lista med score + reasons + blockers

2. **Komponent AIMatchPanel** (src/components/bookings/AIMatchPanel.tsx):
   - Visas i BookingDetailModal när booking.personnel_id IS NULL och stage != 'fakturerad'
   - Anropar useAIMatch(booking_id) hook som invokar edge function
   - Visar topp 3 kandidater i kort sida vid sida
   - Förstaplats markerad med guldram + "BÄSTA MATCH"-badge
   - Varje kort: avatar, namn, hemort, matchpoäng (stor siffra färgkodad), 4 reasons, "Tillsätt"-knapp

3. **Hook useAssignPersonnel**:
   - När man klickar "Tillsätt": uppdaterar booking.personnel_id, sätter stage = 'personal' om var bekraftad
   - Triggar automation 'booking.personnel.assigned' som skickar SMS + kalenderinvite (kommer från Phase 2 Prompt 9)

Test:
- Skapa en booking utan personal i Skövde
- Verifiera att Anna Lindqvist (Skövde-bas) hamnar som #1
- Skapa booking i Stockholm som demo, verifiera att personal med rätt kompetens prioriteras

Lägg till test-personal med varierande egenskaper i en seed-fil för utveckling.
```

---

## PROMPT 12 — Fortnox-integration (Phase 3)

```
Bygg Fortnox-integrationen så fakturaunderlag automatiskt skapas.

Phases:

1. **OAuth2-flöde** (Fortnox kräver OAuth2 sedan 2024):
   - Edge Function `fortnox-oauth-init`: redirectar till Fortnox auth URL
   - Edge Function `fortnox-oauth-callback`: tar emot code, byter mot access_token + refresh_token, lagrar krypterat i org settings
   - UI: Settings-sida för org_admin med "Anslut Fortnox"-knapp

2. **Edge Function `fortnox-create-invoice`** (supabase/functions/fortnox-create-invoice/index.ts):
   - Input: booking_id
   - Hämtar booking + customer + expenses
   - Anropar Fortnox API POST /3/invoices med:
     - CustomerNumber (synkat från customers-tabellen)
     - InvoiceRows: arbetskostnad (timmar × hourly_rate) + utlägg
     - Datum, förfallodag (30 dagar standard)
   - Sparar invoice_id i bookings.fortnox_invoice_id
   - Sätter stage = 'fakturerad'

3. **Customer sync**:
   - Edge Function `fortnox-sync-customers` som körs vid behov
   - Hämtar Fortnox-kundlistan, matchar mot customers-tabellen via org_number eller name
   - Skapar nya customers om de saknas

4. **Trigger**:
   - Automation a5 (Fakturaunderlag till Fortnox) som triggas på `booking.stage.aterrapporterad`
   - Anropar fortnox-create-invoice

5. **UI uppdatering**:
   - InvoicesPage: "Skicka till Fortnox"-knappen blir aktiv om Fortnox är ansluten
   - Visar Fortnox-fakturanummer på fakturerade bokningar

Test: anslut Fortnox sandbox, skapa booking, flytta hela vägen till aterrapporterad, verifiera att faktura skapas i Fortnox.
```

---

## PROMPT 13 — SIE-export (Phase 3)

```
Bygg SIE-export för löneunderlag.

SIE är ett svenskt standardformat (4-format) för bokföringsöverföring. För löner används vanligen extern SIE eller specifika lönesystemsformat (men SIE 4 räcker för de flesta).

Komponenter:

1. **Edge Function `payroll-export-sie`**:
   - Input: month + year
   - Hämtar alla bookings i perioden grupperat per personnel
   - Genererar SIE-text enligt SIE 4-spec:
     - #FLAGGA, #PROGRAM, #FORMAT, #GEN, #SIETYP 4
     - För varje person: konteringsverifikation (lön + utlägg)
   - Returnerar som downloadable text-fil

2. **UI på PayrollPage**:
   - Månads/år-väljare
   - "Generera SIE"-knapp
   - "Generera CSV"-knapp (befintlig)
   - Förhandsgranskning av vad som kommer exporteras

Test: generera SIE för senaste månaden, verifiera att filen kan importeras i Visma/Hogia.

Säg till om du vill att jag dubbelkollar SIE-spec innan vi exporterar.
```

---

## PROMPT 14 — Kalendersync (Phase 3)

```
Bygg tvåvägs kalendersync med Google Calendar och Outlook.

1. **Google Calendar OAuth**:
   - Edge Functions `gcal-oauth-init` + `gcal-oauth-callback`
   - Lagrar tokens per personnel.user_id
   - UI: Settings-sida för personal "Koppla Google Calendar"

2. **Sync-funktion**:
   - Cronjob var 30:e minut: jämför bookings (där personnel.gcal_connected = true) mot Google Calendar events
   - Skapar nya events i Google för bokningar som saknas där
   - Uppdaterar befintliga om något ändrats
   - Tar emot ändringar från Google (avbokning) → markerar booking som behöver uppmärksamhet

3. **Samma för Outlook** (Microsoft Graph API)

4. **Edge Function-trigger**: när booking.stage = 'personal' (tillsatt) → skapa event direkt

Detta är komplext — bryt det i mindre prompts om Claude Code blir överväldigad. Säg åt Claude att börja med Google, få det funktionellt, sedan Outlook.
```

---

## PROMPT 15 — Polish, monitoring, dokumentation (Phase 3 final)

```
Sista biten — gör systemet enterprise-redo:

1. **Sentry-integration** för error tracking
2. **Plausible Analytics** för usage stats (privacy-friendly)
3. **Statuspage** på status.crew2you.se
4. **Monitoring-dashboard** för Adnan/Rasmus i super_admin-vyn:
   - Alla orgs (när vi har fler kunder)
   - Antal aktiva användare per org
   - Edge Function error rates
   - Database storage usage
5. **Användarhandbok** i src/pages/admin/HelpPage.tsx — interaktiv genomgång av alla funktioner
6. **Omfattande testning** av hela flödet
7. **Backup-rutin etablerad** (cronjob som dumpar veckovis till extern storage)

Skriv också:
- docs/USER_MANUAL.md — för Carina och Crew2you-personal
- docs/ADMIN_GUIDE.md — för Samifys interna support

Sista verifiering: full end-to-end test där en bokningsförfrågan kommer via mail, parsas, AI tillsätter personal, personal får SMS, genomför uppdrag, rapporterar in, faktura skapas i Fortnox automatiskt. Hela flödet utan mänsklig handpåläggning från Crew2you.
```

---

## Fel-debug prompts (när något krånglar)

### "Något är konstigt"
```
Något fungerar inte som förväntat. Kör i ordning:

1. `npm run typecheck` — visa output
2. `npm run lint` — visa output
3. `npm run build` — visa output
4. Lista de senaste 5 filerna du ändrade
5. Förklara vad det aktuella tillståndet är

Säg ALDRIG "det borde fungera" — kör verifieringen.
```

### "RLS blockerar mig"
```
Jag får RLS-fel när jag försöker [aktion]. Hjälp mig debugga:

1. Visa exakt vilken policy som ska tillåta detta
2. Kör en test-query mot Supabase som denna user-roll
3. Föreslå om policyn behöver justeras eller om vi använder fel användare

Ändra ALDRIG en RLS policy utan att förklara säkerhetskonsekvenserna först.
```

### "Edge Function deployar inte"
```
Edge Function ${NAME} deployar inte. Kör:

1. `supabase functions list`
2. `supabase functions logs ${NAME} --tail 50`
3. Visa innehållet i functions/${NAME}/index.ts
4. Visa vad jag har för secrets satt: `supabase secrets list`

Identifiera felet och föreslå fix.
```

---

## Slutord

Det här är en stor build — räkna med 6 veckor i full fart eller 12 veckor på sidan av annat jobb. Kör inte sista promptarna för Phase 3 förrän Phase 2 är driftsatt och Crew2you är glada med systemet.

Lycka till! 💪

— Samify Build Team
