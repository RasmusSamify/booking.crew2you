# Roadmap — Crew2you Bokningssystem

Tre faser, ~6 veckor totalt, med driftsättning efter fas 1 så Crew2you kan börja använda systemet medan vi bygger fas 2 och 3.

---

## Fas 0 — Setup (klart i denna repo)

✅ Vite + React + TypeScript skelett
✅ Tailwind med Crew2you design tokens (Montserrat 900, ink + gold)
✅ Supabase-klient + auth store (Zustand)
✅ Rollbaserad routing (admin / personal / kund)
✅ Login-sida (magic link via Supabase OTP)
✅ Layouts för alla tre roller
✅ Komplett databasschema (multitenant + audit + soft delete)
✅ Row Level Security policies på alla tabeller
✅ Seed med Crew2you-org + 9 default automations
✅ Docs och deployment-config

---

## Fas 1 — MVP (vecka 1-2)

**Mål: Crew2you ersätter Excel med systemet. Manuella mailflöden kvarstår.**

### Datamigrering
- [ ] Skript för att importera Excel-data till Supabase (kunder, butiker, personal)
- [ ] Importera 50 senaste bokningar för historik

### Bokningar
- [ ] Pipeline-vy (7 kolumner med drag-and-drop mellan steg)
- [ ] Bokningsregister (tabellvy med filter, sök, sortering)
- [ ] Bokningsdetalj-modal med all info + stage timeline
- [ ] Skapa nytt uppdrag-formulär med autofyll från kund/butik
- [ ] Stage-historik per bokning (vem flyttade när)

### Register
- [ ] Personalregister (kort-vy + detaljmodal med profilegenskaper)
- [ ] Kundregister (med multi-kontakter)
- [ ] Butiksregister (med multi-kontakter + koordinater)

### Personal-app (mobil-PWA)
- [ ] Mina uppdrag-vy
- [ ] Utlägg-formulär med foto-uppladdning till Supabase Storage
- [ ] Återrapport-formulär

### Kundportal (basic)
- [ ] Login + översikt
- [ ] Lista över egna bokningar

### Faktura- och löneunderlag
- [ ] Fakturaunderlag-vy med CSV-export
- [ ] Löneunderlag-vy med CSV-export

### Setup
- [ ] Domän: bokning.crew2you.se
- [ ] SMTP-konfiguration för Supabase Auth (vi byter från default till Resend)
- [ ] Användare för Carina + Crew2you-personal upplagda
- [ ] 1h utbildning med Carina

**Driftsättningskriterier:** Carina kan skapa bokning, tilldela personal, flytta status, skicka faktura. Personal kan se uppdrag och rapportera in utlägg.

---

## Fas 2 — Automationer + AI (vecka 3-4)

**Mål: Kontoret slutar manuellt skicka mail/SMS. AI hanterar inkomna bokningsmail.**

### Autoflow-engine
- [ ] Edge Function: `automation-trigger` som lyssnar på events
- [ ] Resend-integration för transactional mail
- [ ] 46elks-integration för SMS
- [ ] Ical-genererare för kalenderinvites
- [ ] Slack-webhook integration
- [ ] Mail-templates per automation (ändringsbara av org_admin)

### Automationer som aktiveras
- [ ] Bokningsbekräftelse till butik + kund (vid status `bekraftad`)
- [ ] SMS + kalenderinvite till personal (vid `personal` tillsatt)
- [ ] Påminnelse-SMS 24h innan uppdrag (cronjob)
- [ ] Återrapport till uppdragsgivare (vid `report.submitted`)
- [ ] Slack-notis vid utlägg

### AI-mailparsning
- [ ] Edge Function: `ai-parse-email` — tar inkommande mail, extraherar uppdragsinfo
- [ ] Resend Inbound: konfigurera bokning@crew2you.se
- [ ] Inkorg-vy med parsade mail + confidence-markörer
- [ ] "Skapa bokning"-knapp för kompletta mail
- [ ] AI-genererat kompletteringsmail för ofullständiga
- [ ] När kunden svarar: re-parsa och slå ihop med original

### AI-matchning
- [ ] Edge Function: `ai-match-personnel` — räknar matchpoäng (geografi, kompetens, historik)
- [ ] Topp 3 kandidat-vy i bokningsdetaljen
- [ ] "Tillsätt"-knapp som även skickar SMS + kalenderinvite

### Kundportal (utökad)
- [ ] Återrapporter-vy med foton
- [ ] Fakturor-vy

### Veckorapport
- [ ] Cronjob fredag 16:00 → sammanställning till alla aktiva uppdragsgivare

---

## Fas 3 — Enterprise-funktioner (vecka 5-6)

**Mål: Hela ekonomi-flödet automatiserat. Systemet är navet.**

### Fortnox-integration
- [ ] OAuth2-flöde för att koppla Crew2yous Fortnox-konto
- [ ] Auto-skapa fakturaunderlag i Fortnox vid status `aterrapporterad`
- [ ] Synka kundregister mellan Fortnox och systemet
- [ ] Markera bokning som `fakturerad` när faktura skickats

### Lönesystemsexport
- [ ] SIE-format-generator (per period)
- [ ] Export-vy med val av månad + personal

### Kalendersync
- [ ] Google Calendar OAuth
- [ ] Outlook OAuth
- [ ] Tvåvägssync av personalens uppdrag till deras egen kalender

### Domän + SSL
- [ ] bokning.crew2you.se konfigurerad i Netlify
- [ ] DNS-records hos Crew2yous registrar

### SLA + support
- [ ] Statuspage på status.crew2you.se
- [ ] Sentry för error monitoring
- [ ] Plausible Analytics för usage stats
- [ ] Support-runbook

### Strategimöte-rutin
- [ ] Månatligt möte etablerat (kalendariskt)
- [ ] Mall för månadsrapport (KPI:er, ROI, kommande funktioner)

---

## Efter Fas 3 — kontinuerlig utveckling

Utan tidsplan, prioriterade efter Crew2yous behov:

- Drag-and-drop tilldelning av personal (kalendervy)
- Massimport från Excel för engångs-batchjobb
- Push-notiser i personalappen (PWA)
- Konvertering till native app (Expo) om personal klagar
- AI-baserad efterfrågeprognos (när vill kunder ha demos)
- Multi-org självservice för andra bemanningsfirmor (säljbart)
- Stripe för kundbetalningar (om Crew2you vill)
- Mobilapp för admin
- API för tredjepartsintegrationer

---

## Beslutspunkter att stämma av med Crew2you

- [ ] Vilket lönesystem använder de? (avgör SIE-export-formatet)
- [ ] Använder de redan Fortnox eller annat? (avgör fas 3 prioritet)
- [ ] Slack eller Teams för intern kommunikation? (avgör notis-integration)
- [ ] Fri utbildning ingår — när passar för 1h-genomgång med Carina?
- [ ] Vilken mailadress ska bokning@-mailen gå till? (bokning@crew2you.se?)
