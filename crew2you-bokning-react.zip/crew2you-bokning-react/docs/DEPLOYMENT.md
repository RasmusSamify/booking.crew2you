# Deployment

Production-setup för Crew2you Bokningssystem.

---

## Översikt

- **Frontend:** Netlify (auto-deploy från `main`)
- **Backend:** Supabase (Stockholm, eu-north-1)
- **Mail:** Resend
- **SMS:** 46elks
- **Domän:** bokning.crew2you.se (Cloudflare/Loopia/wherever Crew2you har sin DNS)

---

## 1. Supabase setup (engångs)

1. Skapa projekt på [supabase.com](https://supabase.com)
   - Region: **Stockholm (eu-north-1)** ← obligatoriskt för GDPR och latency
   - Plan: **Pro** ($25/mån) — krävs för daglig backup och SLA
2. Project Settings → API → kopiera:
   - URL → `VITE_SUPABASE_URL`
   - anon key → `VITE_SUPABASE_ANON_KEY`
   - service_role key → spara i 1Password (används i Edge Functions)
3. Authentication → Providers → enable Email, sätt:
   - Site URL: `https://bokning.crew2you.se`
   - Redirect URLs: `https://bokning.crew2you.se/auth/callback`
4. Authentication → Email Templates → byt till Resend SMTP (se Resend-sektion nedan)
5. Storage → skapa buckets:
   - `receipts` (private, för utlägg-foton)
   - `reports` (private, för återrapport-foton)
   - `branding` (public, för loggor och avatarer)

---

## 2. Migrations

```bash
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

Verifiera i Supabase Studio att alla tabeller och RLS policies finns.

---

## 3. Resend setup

1. Skapa konto på [resend.com](https://resend.com)
2. Lägg till domän `crew2you.se` (eller `samify.se` initialt) — verifiera DNS
3. Skapa API-nyckel
4. Konfigurera SMTP i Supabase Auth:
   - Host: `smtp.resend.com`
   - Port: `465`
   - Username: `resend`
   - Password: `[API key]`
   - Sender email: `bokning@crew2you.se`
   - Sender name: `Crew2you Bokning`

För **inkommande mail** (AI-parsning):
1. Resend → Inbound → skapa endpoint som pekar på Supabase Edge Function `ai-parse-email`
2. Konfigurera MX-record för `bokning@crew2you.se` att peka på Resend

---

## 4. 46elks setup (SMS)

1. Skapa konto på [46elks.se](https://46elks.se)
2. Köp ett nummer eller använd alfanumeriskt avsändarnamn `Crew2you`
3. Hämta API username + password
4. Lägg till i Supabase Edge Function env vars

---

## 5. Anthropic API

1. Konto på [console.anthropic.com](https://console.anthropic.com)
2. Skapa API key
3. Sätt usage limits (förslagsvis $50/mån initialt)
4. Lägg till i Supabase Edge Function env vars

---

## 6. Netlify deployment

1. Logga in på [netlify.com](https://netlify.com) → "Add new site" → "Import from Git"
2. Välj GitHub-repot
3. Build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. Environment variables:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
5. Deploy

### Egen domän (bokning.crew2you.se)

I Netlify → Domain settings → Add custom domain → `bokning.crew2you.se`

I Crew2yous DNS:
```
CNAME bokning -> [netlify-provided-target].netlify.app
```

Netlify ordnar SSL automatiskt via Let's Encrypt.

---

## 7. Edge Functions deployment

```bash
supabase functions deploy ai-parse-email
supabase functions deploy ai-match-personnel
supabase functions deploy fortnox-sync
```

Sätt secrets:

```bash
supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
supabase secrets set RESEND_API_KEY=re_...
supabase secrets set ELKS_USERNAME=...
supabase secrets set ELKS_PASSWORD=...
supabase secrets set FORTNOX_CLIENT_ID=...
supabase secrets set FORTNOX_CLIENT_SECRET=...
```

---

## 8. Användarsetup

Från Supabase Studio → Authentication → Users → Add user:

| E-post | Roll (sätts automatiskt) |
|---|---|
| adnan@samify.se | super_admin |
| rasmus@samify.se | super_admin |
| carina@crew2you.se | org_user (uppdatera till org_admin manuellt) |

För Carina:
```sql
UPDATE user_profiles
SET role = 'org_admin', full_name = 'Carina [Efternamn]'
WHERE email = 'carina@crew2you.se';
```

För personal — när varje demovärd ska få access:
```sql
-- Efter att användaren skapats
UPDATE user_profiles SET role = 'personnel' WHERE email = 'lars@crew2you.se';
UPDATE personnel SET user_id = (SELECT id FROM user_profiles WHERE email = 'lars@crew2you.se')
WHERE full_name = 'Lars Djupsjö';
```

För kunder — när en uppdragsgivare ska få portalåtkomst:
```sql
UPDATE user_profiles SET role = 'customer' WHERE email = 'jenny@falbygdens.se';
UPDATE customers SET user_id = (SELECT id FROM user_profiles WHERE email = 'jenny@falbygdens.se')
WHERE name = 'Falbygdens Ost';
```

---

## 9. Monitoring (rekommenderas)

- **Sentry** för error tracking — `npm install @sentry/react`
- **Plausible** för usage analytics — privacy-vänligt, GDPR-säkert
- **UptimeRobot** för status-monitoring av bokning.crew2you.se

---

## 10. Backups

Supabase Pro tar daglig backup automatiskt. Förvaras 7 dagar.

För extra säkerhet, skapa cronjob som dumpar varje vecka till Crew2yous egen S3/Backblaze:

```bash
supabase db dump > backup-$(date +%Y%m%d).sql
```

---

## Disaster recovery

Om Supabase går ner / vi tappar projektet:

1. Skapa nytt Supabase-projekt
2. Återställ från backup: `psql ... < backup.sql`
3. Uppdatera `VITE_SUPABASE_URL` i Netlify
4. Re-deploy

Total downtime: ~30 min.

---

## Kostnadsuppskattning (månadsvis)

| Tjänst | Kostnad |
|---|---|
| Supabase Pro | $25 (~270 kr) |
| Netlify Pro (för Functions-limits) | $19 (~210 kr) |
| Resend (Pro 50k mail/mån) | $20 (~220 kr) |
| 46elks SMS (~500/mån) | ~175 kr |
| Anthropic API (uppskattning) | ~150 kr |
| **Totalt drift** | **~1 025 kr/mån** |

Marginalen i Enterprise-paketet (14 995 kr/mån) är god.
