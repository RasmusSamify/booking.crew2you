import { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/stores/auth';
import { LoginPage } from '@/pages/auth/LoginPage';
import { AuthCallbackPage } from '@/pages/auth/AuthCallbackPage';
import { AdminLayout } from '@/components/layout/AdminLayout';
import { PersonalLayout } from '@/components/layout/PersonalLayout';
import { KundLayout } from '@/components/layout/KundLayout';
import { DashboardPage } from '@/pages/admin/DashboardPage';
import { ProtectedRoute } from '@/routes/ProtectedRoute';
import { LoadingScreen } from '@/components/ui/LoadingScreen';

export default function App() {
  const { loading, init, profile } = useAuth();

  useEffect(() => {
    init();
  }, [init]);

  if (loading) return <LoadingScreen />;

  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/auth/callback" element={<AuthCallbackPage />} />

      {/* Admin routes */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute allowedRoles={['super_admin', 'org_admin', 'org_user']}>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<DashboardPage />} />
        {/* More routes added in Phase 1 */}
      </Route>

      {/* Personal routes */}
      <Route
        path="/personal"
        element={
          <ProtectedRoute allowedRoles={['personnel']}>
            <PersonalLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<div>Personal-app kommer i Phase 1</div>} />
      </Route>

      {/* Kund routes */}
      <Route
        path="/kund"
        element={
          <ProtectedRoute allowedRoles={['customer']}>
            <KundLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<div>Kundportal kommer i Phase 1</div>} />
      </Route>

      {/* Default redirect based on role */}
      <Route
        path="*"
        element={
          profile ? (
            profile.role === 'personnel' ? (
              <Navigate to="/personal" replace />
            ) : profile.role === 'customer' ? (
              <Navigate to="/kund" replace />
            ) : (
              <Navigate to="/admin" replace />
            )
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />
    </Routes>
  );
}
