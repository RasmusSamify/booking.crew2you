import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/stores/auth';
import { LoadingScreen } from '@/components/ui/LoadingScreen';

export function AuthCallbackPage() {
  const navigate = useNavigate();
  const { session, profile, loading } = useAuth();

  useEffect(() => {
    if (loading) return;
    if (!session) navigate('/login', { replace: true });
    else if (profile) {
      const path =
        profile.role === 'personnel' ? '/personal' :
        profile.role === 'customer' ? '/kund' :
        '/admin';
      navigate(path, { replace: true });
    }
  }, [session, profile, loading, navigate]);

  return <LoadingScreen />;
}
