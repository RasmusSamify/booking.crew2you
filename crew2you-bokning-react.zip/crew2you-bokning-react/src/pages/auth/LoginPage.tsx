import { useState } from 'react';
import { useAuth } from '@/stores/auth';

const LOGO_URL = 'https://axypazcbgcogtdqqimvi.supabase.co/storage/v1/object/public/Bilder/main-logo.png';

export function LoginPage() {
  const { signInWithEmail } = useAuth();
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    const { error } = await signInWithEmail(email);
    setSubmitting(false);
    if (error) setError(error.message);
    else setSent(true);
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-5"
      style={{
        background: `radial-gradient(circle at 20% 30%, rgba(196, 167, 88, 0.08) 0%, transparent 50%),
                     radial-gradient(circle at 80% 70%, rgba(196, 167, 88, 0.05) 0%, transparent 50%),
                     #faf8f3`
      }}
    >
      <div className="bg-surface rounded-r-xl border border-border shadow-lg p-12 max-w-md w-full">
        <div className="flex justify-center mb-7">
          <img src={LOGO_URL} alt="Crew2you" className="h-20 w-auto" />
        </div>
        <h1 className="text-2xl font-black text-center text-ink mb-2 tracking-tight">Bokningssystem</h1>
        <p className="text-center text-ink-muted text-sm mb-8">Logga in med din e-postadress.</p>

        {sent ? (
          <div className="bg-gold-bg border border-gold-light rounded-r p-4 text-center">
            <p className="text-ink font-semibold mb-1">Mail skickat!</p>
            <p className="text-ink-soft text-sm">
              Vi har skickat en magic link till <strong>{email}</strong>. Klicka på länken för att logga in.
            </p>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="label">E-post</label>
              <input
                id="email"
                type="email"
                required
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input"
                placeholder="namn@crew2you.se"
              />
            </div>
            {error && <p className="text-red-600 text-sm">{error}</p>}
            <button type="submit" disabled={submitting} className="btn btn-primary w-full justify-center">
              {submitting ? 'Skickar...' : 'Skicka magic link'}
            </button>
          </form>
        )}

        <p className="text-center text-xs text-ink-faint mt-8">
          Byggt av <a href="https://samify.se" className="text-gold-dark font-semibold">Samify</a>
        </p>
      </div>
    </div>
  );
}
