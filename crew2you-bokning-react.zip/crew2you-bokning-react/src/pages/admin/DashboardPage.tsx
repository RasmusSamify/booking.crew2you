import { Calendar, Clock, Receipt, Wallet } from 'lucide-react';
import { useAuth } from '@/stores/auth';

export function DashboardPage() {
  const { profile } = useAuth();

  return (
    <div className="flex flex-col flex-1">
      <header className="bg-surface px-8 py-5 border-b border-border sticky top-0 z-[5] flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-ink tracking-tight">Översikt</h1>
          <p className="text-sm text-ink-muted mt-0.5">Vad händer i Crew2you idag</p>
        </div>
        <div className="text-sm text-ink-muted">
          Hej {profile?.full_name?.split(' ')[0] ?? ''} 👋
        </div>
      </header>

      <div className="flex-1 p-8 overflow-y-auto">
        <div className="bg-gold-bg border border-gold-light rounded-r-lg p-6 mb-6">
          <h2 className="text-lg font-black text-ink mb-2">Välkommen till Crew2you Bokningssystem</h2>
          <p className="text-ink-soft text-sm">
            Detta är en helt nybyggd version i React + Supabase. Funktionerna byggs in fas för fas
            enligt projektplanen. Just nu är auth + grundstruktur på plats — nästa steg är pipelinen
            och bokningsregistret.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Aktiva uppdrag', value: '–', icon: Calendar },
            { label: 'Kommande vecka', value: '–', icon: Clock },
            { label: 'Att fakturera', value: '–', icon: Receipt },
            { label: 'Utlägg denna månad', value: '–', icon: Wallet },
          ].map((kpi) => (
            <div key={kpi.label} className="card p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold uppercase tracking-wide text-ink-muted">{kpi.label}</span>
                <div className="w-8 h-8 rounded-r-sm bg-gold-bg text-gold-dark flex items-center justify-center">
                  <kpi.icon className="w-4 h-4" strokeWidth={1.75} />
                </div>
              </div>
              <div className="text-3xl font-black text-ink tracking-tight">{kpi.value}</div>
              <div className="text-xs text-ink-muted mt-1.5">Data laddas när migration körts</div>
            </div>
          ))}
        </div>

        <div className="card p-8 text-center">
          <p className="text-ink-muted">
            <strong className="text-ink">Phase 1</strong> — bokningspipeline, register och mobilapp byggs härnäst.<br />
            Se <code className="bg-surface-alt px-1.5 py-0.5 rounded text-xs">docs/ROADMAP.md</code> för
            den fullständiga planen.
          </p>
        </div>
      </div>
    </div>
  );
}
