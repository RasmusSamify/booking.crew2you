import { Outlet, NavLink } from 'react-router-dom';
import { useAuth } from '@/stores/auth';
import { LogOut } from 'lucide-react';
import { cn } from '@/lib/utils';

export function PersonalLayout() {
  const { profile, signOut } = useAuth();
  const initials = profile?.full_name?.split(' ').map(w => w[0]).slice(0, 2).join('') ?? '–';

  return (
    <div className="min-h-screen bg-bg">
      <div className="max-w-[440px] mx-auto my-6 bg-surface min-h-[calc(100vh-48px)] shadow-lg rounded-r-xl overflow-hidden pb-6">
        <header className="bg-ink text-white px-5 py-5 flex justify-between items-center">
          <div>
            <div className="text-xs opacity-60 font-medium">God morgon</div>
            <div className="text-base font-semibold mt-0.5">{profile?.full_name ?? 'Demovärd'}</div>
          </div>
          <div className="flex gap-2 items-center">
            <button
              onClick={() => signOut()}
              className="px-2.5 py-1.5 bg-white/10 text-white rounded-r-sm text-xs font-medium flex items-center gap-1"
            >
              <LogOut className="w-3.5 h-3.5" strokeWidth={2} />
            </button>
            <div className="w-10 h-10 rounded-full bg-gold text-white flex items-center justify-center font-bold text-sm">
              {initials}
            </div>
          </div>
        </header>

        <div className="flex bg-surface border-b border-border sticky top-0 z-10">
          <NavLink to="/personal" end className={({ isActive }) => tabClasses(isActive)}>
            Uppdrag
          </NavLink>
          <NavLink to="/personal/expenses" className={({ isActive }) => tabClasses(isActive)}>
            Utlägg
          </NavLink>
          <NavLink to="/personal/reports" className={({ isActive }) => tabClasses(isActive)}>
            Återrapport
          </NavLink>
        </div>

        <div className="p-4">
          <Outlet />
        </div>
      </div>
    </div>
  );
}

function tabClasses(isActive: boolean) {
  return cn(
    'flex-1 py-3.5 px-2 text-xs font-semibold border-b-2 transition-colors text-center',
    isActive
      ? 'text-ink border-gold'
      : 'text-ink-muted border-transparent hover:text-ink'
  );
}
