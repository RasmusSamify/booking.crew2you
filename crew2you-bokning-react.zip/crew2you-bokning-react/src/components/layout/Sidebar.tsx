import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard, Inbox, Calendar, Users, Building2, Receipt, Wallet, Zap, LogOut, GitBranch
} from 'lucide-react';
import { useAuth } from '@/stores/auth';
import { cn } from '@/lib/utils';

const LOGO_URL = 'https://axypazcbgcogtdqqimvi.supabase.co/storage/v1/object/public/Bilder/main-logo.png';

const adminNav = [
  { to: '/admin', icon: LayoutDashboard, label: 'Översikt', end: true },
  { to: '/admin/inbox', icon: Inbox, label: 'Inkorg', badge: 'AI' },
  { to: '/admin/pipeline', icon: GitBranch, label: 'Pipeline' },
  { to: '/admin/bookings', icon: Calendar, label: 'Bokningar' },
  { to: '/admin/personnel', icon: Users, label: 'Personal' },
  { to: '/admin/customers', icon: Building2, label: 'Kunder & butiker' },
  { to: '/admin/invoices', icon: Receipt, label: 'Fakturaunderlag' },
  { to: '/admin/payroll', icon: Wallet, label: 'Löneunderlag' },
  { to: '/admin/automations', icon: Zap, label: 'Automationer', badge: 'AUTOFLOW' },
];

export function Sidebar() {
  const { profile, signOut } = useAuth();

  return (
    <aside className="w-[248px] bg-surface border-r border-border flex flex-col h-screen sticky top-0 flex-shrink-0">
      <div className="p-6 border-b border-border flex justify-center">
        <img src={LOGO_URL} alt="Crew2you" className="h-12 w-auto" />
      </div>

      <div className="px-6 pt-3.5 pb-2.5 text-[11px] font-semibold uppercase tracking-wider text-ink-faint">
        Inloggad som <strong className="text-gold-dark font-bold">{roleLabel(profile?.role)}</strong>
      </div>

      <nav className="flex-1 px-3 pb-3 overflow-y-auto">
        {adminNav.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-r text-sm font-medium transition-colors relative',
                isActive
                  ? 'bg-gold-bg text-gold-dark font-semibold'
                  : 'text-ink-soft hover:bg-surface-alt hover:text-ink'
              )
            }
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <span className="absolute -left-3 top-2 bottom-2 w-[3px] bg-gold rounded-r" />
                )}
                <item.icon className="w-[18px] h-[18px]" strokeWidth={1.75} />
                <span className="flex-1">{item.label}</span>
                {item.badge && (
                  <span className={cn(
                    'text-[10px] px-1.5 py-0.5 rounded-full font-bold tracking-wider',
                    item.badge === 'AI' ? 'bg-red-500 text-white' : 'bg-gold text-white'
                  )}>
                    {item.badge}
                  </span>
                )}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="p-5 border-t border-border">
        <div className="text-xs text-ink-muted mb-3 px-1">
          {profile?.full_name}<br />
          <span className="text-ink-faint">{profile?.email}</span>
        </div>
        <button
          onClick={() => signOut()}
          className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 bg-surface-alt text-ink-soft rounded-r text-sm font-medium hover:bg-border hover:text-ink transition-colors"
        >
          <LogOut className="w-3.5 h-3.5" strokeWidth={2} />
          Logga ut
        </button>
      </div>
    </aside>
  );
}

function roleLabel(role?: string) {
  switch (role) {
    case 'super_admin': return 'Samify Admin';
    case 'org_admin': return 'Admin';
    case 'org_user': return 'Kontor';
    case 'personnel': return 'Personal';
    case 'customer': return 'Kund';
    default: return '–';
  }
}
