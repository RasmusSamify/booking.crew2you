import { Outlet, NavLink } from 'react-router-dom';
import { Home, Calendar, Clipboard, Receipt, LogOut } from 'lucide-react';
import { useAuth } from '@/stores/auth';
import { cn } from '@/lib/utils';

const LOGO_URL = 'https://axypazcbgcogtdqqimvi.supabase.co/storage/v1/object/public/Bilder/main-logo.png';

const nav = [
  { to: '/kund', icon: Home, label: 'Översikt', end: true },
  { to: '/kund/bookings', icon: Calendar, label: 'Mina bokningar' },
  { to: '/kund/reports', icon: Clipboard, label: 'Återrapporter' },
  { to: '/kund/invoices', icon: Receipt, label: 'Fakturor' },
];

export function KundLayout() {
  const { profile, signOut } = useAuth();
  return (
    <div className="flex min-h-screen">
      <aside className="w-[248px] bg-surface border-r border-border flex flex-col h-screen sticky top-0 flex-shrink-0">
        <div className="p-6 border-b border-border flex justify-center">
          <img src={LOGO_URL} alt="Crew2you" className="h-12 w-auto" />
        </div>
        <div className="px-6 pt-3.5 pb-2.5 text-[11px] font-semibold uppercase tracking-wider text-ink-faint">
          Inloggad som <strong className="text-gold-dark font-bold">{profile?.full_name ?? 'Kund'}</strong>
        </div>
        <nav className="flex-1 px-3 pb-3">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-r text-sm font-medium transition-colors relative',
                  isActive ? 'bg-gold-bg text-gold-dark font-semibold' : 'text-ink-soft hover:bg-surface-alt hover:text-ink'
                )
              }
            >
              <item.icon className="w-[18px] h-[18px]" strokeWidth={1.75} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="p-5 border-t border-border">
          <button onClick={() => signOut()} className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 bg-surface-alt text-ink-soft rounded-r text-sm font-medium hover:bg-border">
            <LogOut className="w-3.5 h-3.5" /> Logga ut
          </button>
        </div>
      </aside>
      <main className="flex-1 p-8">
        <Outlet />
      </main>
    </div>
  );
}
