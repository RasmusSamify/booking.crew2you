// Edge Function: AI Parse Email
// Tar emot inkommande mail från Resend Inbound, extraherar uppdragsinfo med Claude
// och sparar i inbox_emails.
//
// Implementeras i Phase 2 (se docs/CLAUDE_CODE_PROMPTS.md → Prompt 10)

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';

serve(async (_req) => {
  return new Response(
    JSON.stringify({
      status: 'placeholder',
      message: 'Implementeras i Phase 2',
    }),
    { headers: { 'Content-Type': 'application/json' } }
  );
});
