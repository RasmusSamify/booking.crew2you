// Edge Function: Fortnox Sync
// Skapar fakturaunderlag i Fortnox, synkar kunder.
//
// Implementeras i Phase 3 (se docs/CLAUDE_CODE_PROMPTS.md → Prompt 12)

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';

serve(async (_req) => {
  return new Response(
    JSON.stringify({
      status: 'placeholder',
      message: 'Implementeras i Phase 3',
    }),
    { headers: { 'Content-Type': 'application/json' } }
  );
});
