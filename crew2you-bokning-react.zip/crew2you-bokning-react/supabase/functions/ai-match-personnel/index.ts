// Edge Function: AI Match Personnel
// Beräknar matchscore (geografi, kompetens, historik) för alla personnel mot en booking.
//
// Implementeras i Phase 2 (se docs/CLAUDE_CODE_PROMPTS.md → Prompt 11)

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';

serve(async (_req) => {
  return new Response(
    JSON.stringify({
      status: 'placeholder',
      message: 'Implementeras i Phase 2',
    }),
    { headers: { 'Content-Type': 'application/json' } }
  );
});
