-- ============================================================================
-- Crew2you Bokningssystem — Initial Schema
-- ============================================================================
-- Multitenant foundation. Every table has org_id for tenant isolation.
-- Soft delete via deleted_at on all main entities.
-- Audit log captures every mutation.
-- ============================================================================

-- ============ ENUMS ============
CREATE TYPE user_role AS ENUM (
  'super_admin',  -- Samify staff (Adnan, Rasmus) - can impersonate any org
  'org_admin',    -- Customer admin (Carina at Crew2you) - full org access
  'org_user',     -- Org office staff - manage bookings, no settings
  'personnel',    -- Demo staff - own assignments + expenses
  'customer'      -- External customer (uppdragsgivare) - their bookings only
);

CREATE TYPE booking_stage AS ENUM (
  'inkommen',
  'bokad',
  'bekraftad',
  'personal',
  'genomford',
  'aterrapporterad',
  'fakturerad'
);

CREATE TYPE service_type AS ENUM (
  'demo',
  'plock',
  'sampling',
  'event',
  'annat'
);

CREATE TYPE expense_type AS ENUM (
  'material',
  'milersattning',
  'parkering',
  'mat_fika',
  'ovrigt'
);

-- ============ ORGANIZATIONS (tenants) ============
CREATE TABLE organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  org_number TEXT,
  address TEXT,
  logo_url TEXT,
  settings JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  deleted_at TIMESTAMPTZ
);

-- ============ USER PROFILES ============
-- Extends auth.users with role + org binding
CREATE TABLE user_profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'org_user',
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_user_profiles_org ON user_profiles(org_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_user_profiles_email ON user_profiles(email);

-- ============ CUSTOMERS (uppdragsgivare) ============
CREATE TABLE customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  org_number TEXT,
  address TEXT,
  notes TEXT,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL, -- if customer has portal login
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_customers_org ON customers(org_id) WHERE deleted_at IS NULL;

CREATE TABLE customer_contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT,
  phone TEXT,
  email TEXT,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_customer_contacts_customer ON customer_contacts(customer_id) WHERE deleted_at IS NULL;

-- ============ STORES (butiker) ============
CREATE TABLE stores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  city TEXT,
  region TEXT,
  address TEXT,
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_stores_org ON stores(org_id) WHERE deleted_at IS NULL;

CREATE TABLE store_contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT,
  phone TEXT,
  email TEXT,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_store_contacts_store ON store_contacts(store_id) WHERE deleted_at IS NULL;

-- ============ PERSONNEL (demovärdar) ============
CREATE TABLE personnel (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name TEXT NOT NULL,
  initials TEXT,
  phone TEXT,
  email TEXT,
  home_city TEXT,
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  max_radius_km INTEGER DEFAULT 50,
  competencies TEXT[] DEFAULT '{}',
  specialties TEXT[] DEFAULT '{}',
  languages TEXT[] DEFAULT '{}',
  certifications TEXT[] DEFAULT '{}',
  availability TEXT,
  experience_years INTEGER DEFAULT 0,
  rating NUMERIC(3,2) DEFAULT 0,
  total_assignments INTEGER DEFAULT 0,
  notes TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_personnel_org ON personnel(org_id) WHERE deleted_at IS NULL;

-- ============ BOOKINGS ============
CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  store_id UUID REFERENCES stores(id) ON DELETE SET NULL,
  store_contact_id UUID REFERENCES store_contacts(id) ON DELETE SET NULL,
  customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
  customer_contact_id UUID REFERENCES customer_contacts(id) ON DELETE SET NULL,
  personnel_id UUID REFERENCES personnel(id) ON DELETE SET NULL,

  -- Snapshot fields (for resilience if relations are deleted)
  store_name TEXT NOT NULL,
  customer_name TEXT,

  service_type service_type NOT NULL DEFAULT 'demo',
  stage booking_stage NOT NULL DEFAULT 'inkommen',

  scheduled_date DATE,
  schedule_text TEXT, -- e.g. "tis 10-18" or "mån+tor"
  hours NUMERIC(5,2),

  product TEXT,
  material TEXT,
  shipment TEXT,
  info TEXT,
  other_info TEXT,

  -- Aftermath
  report TEXT,
  report_photo_url TEXT,
  actual_hours NUMERIC(5,2),
  sold_volume TEXT,

  -- Invoicing
  hourly_rate NUMERIC(10,2),
  invoiced_at TIMESTAMPTZ,
  fortnox_invoice_id TEXT,

  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  deleted_at TIMESTAMPTZ,
  created_by UUID REFERENCES auth.users(id)
);
CREATE INDEX idx_bookings_org ON bookings(org_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_bookings_stage ON bookings(org_id, stage) WHERE deleted_at IS NULL;
CREATE INDEX idx_bookings_personnel ON bookings(personnel_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_bookings_customer ON bookings(customer_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_bookings_date ON bookings(scheduled_date) WHERE deleted_at IS NULL;

-- ============ BOOKING STAGE HISTORY ============
CREATE TABLE booking_stage_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  from_stage booking_stage,
  to_stage booking_stage NOT NULL,
  changed_by UUID REFERENCES auth.users(id),
  changed_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  note TEXT
);
CREATE INDEX idx_stage_history_booking ON booking_stage_history(booking_id);

-- ============ EXPENSES ============
CREATE TABLE expenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE,
  personnel_id UUID NOT NULL REFERENCES personnel(id) ON DELETE CASCADE,
  expense_type expense_type NOT NULL,
  amount NUMERIC(10,2) NOT NULL,
  description TEXT,
  receipt_url TEXT,
  expense_date DATE DEFAULT CURRENT_DATE,
  reimbursed BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_expenses_org ON expenses(org_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_expenses_booking ON expenses(booking_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_expenses_personnel ON expenses(personnel_id) WHERE deleted_at IS NULL;

-- ============ AUTOMATIONS ============
CREATE TABLE automations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  trigger_event TEXT NOT NULL, -- e.g. 'booking.stage.bekraftad'
  actions JSONB NOT NULL DEFAULT '[]'::jsonb,
  enabled BOOLEAN DEFAULT true,
  total_runs INTEGER DEFAULT 0,
  last_run_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);
CREATE INDEX idx_automations_org ON automations(org_id);

CREATE TABLE automation_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  automation_id UUID NOT NULL REFERENCES automations(id) ON DELETE CASCADE,
  trigger_data JSONB,
  result JSONB,
  status TEXT NOT NULL DEFAULT 'success', -- success | failed | partial
  error_message TEXT,
  ran_at TIMESTAMPTZ DEFAULT now() NOT NULL
);
CREATE INDEX idx_automation_runs_org ON automation_runs(org_id, ran_at DESC);
CREATE INDEX idx_automation_runs_automation ON automation_runs(automation_id, ran_at DESC);

-- ============ INBOX (mailparsning) ============
CREATE TABLE inbox_emails (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  from_name TEXT,
  from_email TEXT NOT NULL,
  subject TEXT,
  body TEXT,
  received_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  parsed_data JSONB,
  parse_status TEXT DEFAULT 'pending', -- pending | complete | partial | incomplete | booked
  missing_fields JSONB DEFAULT '[]'::jsonb,
  auto_reply_sent_at TIMESTAMPTZ,
  booking_id UUID REFERENCES bookings(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);
CREATE INDEX idx_inbox_org ON inbox_emails(org_id, received_at DESC);

-- ============ AUDIT LOG ============
CREATE TABLE audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL,
  actor_id UUID REFERENCES auth.users(id),
  actor_email TEXT,
  action TEXT NOT NULL, -- 'create' | 'update' | 'delete' | 'login' | 'impersonate'
  entity_type TEXT NOT NULL,
  entity_id UUID,
  changes JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);
CREATE INDEX idx_audit_org ON audit_log(org_id, created_at DESC);
CREATE INDEX idx_audit_entity ON audit_log(entity_type, entity_id);

-- ============ updated_at TRIGGERS ============
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_organizations_updated BEFORE UPDATE ON organizations
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_user_profiles_updated BEFORE UPDATE ON user_profiles
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_customers_updated BEFORE UPDATE ON customers
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_stores_updated BEFORE UPDATE ON stores
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_personnel_updated BEFORE UPDATE ON personnel
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_bookings_updated BEFORE UPDATE ON bookings
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_automations_updated BEFORE UPDATE ON automations
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
