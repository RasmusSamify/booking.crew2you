-- ============================================================================
-- Row Level Security (RLS) Policies
-- ============================================================================
-- Multitenant isolation: every query is scoped by org_id automatically.
-- Roles enforced at database level, not just app level.
-- super_admin bypasses tenant isolation (Samify support).
-- ============================================================================

-- ============ HELPER: Get current user's org_id and role ============
CREATE OR REPLACE FUNCTION auth.user_org_id()
RETURNS UUID
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT org_id FROM user_profiles WHERE id = auth.uid() AND deleted_at IS NULL;
$$;

CREATE OR REPLACE FUNCTION auth.user_role()
RETURNS user_role
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT role FROM user_profiles WHERE id = auth.uid() AND deleted_at IS NULL;
$$;

CREATE OR REPLACE FUNCTION auth.is_super_admin()
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS(SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role = 'super_admin' AND deleted_at IS NULL);
$$;

-- ============ ENABLE RLS ============
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;
ALTER TABLE store_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE personnel ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE booking_stage_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE automations ENABLE ROW LEVEL SECURITY;
ALTER TABLE automation_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE inbox_emails ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

-- ============ ORGANIZATIONS ============
CREATE POLICY "View own org" ON organizations FOR SELECT
  USING (id = auth.user_org_id() OR auth.is_super_admin());

CREATE POLICY "Super admin manages orgs" ON organizations FOR ALL
  USING (auth.is_super_admin());

-- ============ USER PROFILES ============
CREATE POLICY "View users in same org" ON user_profiles FOR SELECT
  USING (org_id = auth.user_org_id() OR auth.is_super_admin());

CREATE POLICY "Org admin manages users" ON user_profiles FOR ALL
  USING (
    (org_id = auth.user_org_id() AND auth.user_role() = 'org_admin')
    OR auth.is_super_admin()
  );

CREATE POLICY "Users update own profile" ON user_profiles FOR UPDATE
  USING (id = auth.uid());

-- ============ CUSTOMERS ============
CREATE POLICY "View org customers" ON customers FOR SELECT
  USING (org_id = auth.user_org_id() OR auth.is_super_admin());

CREATE POLICY "Org users manage customers" ON customers FOR ALL
  USING (
    (org_id = auth.user_org_id() AND auth.user_role() IN ('org_admin', 'org_user'))
    OR auth.is_super_admin()
  );

CREATE POLICY "Customer sees own record" ON customers FOR SELECT
  USING (user_id = auth.uid());

-- ============ CUSTOMER CONTACTS ============
CREATE POLICY "View customer contacts via org" ON customer_contacts FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = customer_id
      AND (c.org_id = auth.user_org_id() OR auth.is_super_admin())
    )
  );

CREATE POLICY "Org users manage customer contacts" ON customer_contacts FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = customer_id
      AND c.org_id = auth.user_org_id()
      AND auth.user_role() IN ('org_admin', 'org_user')
    ) OR auth.is_super_admin()
  );

-- ============ STORES ============
CREATE POLICY "View org stores" ON stores FOR SELECT
  USING (org_id = auth.user_org_id() OR auth.is_super_admin());

CREATE POLICY "Org users manage stores" ON stores FOR ALL
  USING (
    (org_id = auth.user_org_id() AND auth.user_role() IN ('org_admin', 'org_user'))
    OR auth.is_super_admin()
  );

-- ============ STORE CONTACTS ============
CREATE POLICY "View store contacts via org" ON store_contacts FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM stores s
      WHERE s.id = store_id
      AND (s.org_id = auth.user_org_id() OR auth.is_super_admin())
    )
  );

CREATE POLICY "Org users manage store contacts" ON store_contacts FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM stores s
      WHERE s.id = store_id
      AND s.org_id = auth.user_org_id()
      AND auth.user_role() IN ('org_admin', 'org_user')
    ) OR auth.is_super_admin()
  );

-- ============ PERSONNEL ============
CREATE POLICY "View org personnel" ON personnel FOR SELECT
  USING (org_id = auth.user_org_id() OR auth.is_super_admin());

CREATE POLICY "Org users manage personnel" ON personnel FOR ALL
  USING (
    (org_id = auth.user_org_id() AND auth.user_role() IN ('org_admin', 'org_user'))
    OR auth.is_super_admin()
  );

CREATE POLICY "Personnel sees own record" ON personnel FOR SELECT
  USING (user_id = auth.uid());

-- ============ BOOKINGS ============
CREATE POLICY "Org sees all bookings" ON bookings FOR SELECT
  USING (org_id = auth.user_org_id() OR auth.is_super_admin());

CREATE POLICY "Org users manage bookings" ON bookings FOR ALL
  USING (
    (org_id = auth.user_org_id() AND auth.user_role() IN ('org_admin', 'org_user'))
    OR auth.is_super_admin()
  );

CREATE POLICY "Personnel sees own bookings" ON bookings FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM personnel p
      WHERE p.id = personnel_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY "Personnel updates own bookings (report only)" ON bookings FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM personnel p
      WHERE p.id = personnel_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY "Customer sees own bookings" ON bookings FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = customer_id
      AND c.user_id = auth.uid()
    )
  );

-- ============ BOOKING STAGE HISTORY ============
CREATE POLICY "View stage history via booking" ON booking_stage_history FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM bookings b
      WHERE b.id = booking_id
      AND (b.org_id = auth.user_org_id() OR auth.is_super_admin())
    )
  );

CREATE POLICY "System inserts stage history" ON booking_stage_history FOR INSERT
  WITH CHECK (true); -- Inserted via trigger or edge function

-- ============ EXPENSES ============
CREATE POLICY "Org sees all expenses" ON expenses FOR SELECT
  USING (org_id = auth.user_org_id() OR auth.is_super_admin());

CREATE POLICY "Personnel sees own expenses" ON expenses FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM personnel p
      WHERE p.id = personnel_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY "Personnel creates own expenses" ON expenses FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM personnel p
      WHERE p.id = personnel_id
      AND p.user_id = auth.uid()
    )
  );

CREATE POLICY "Org users manage expenses" ON expenses FOR ALL
  USING (
    (org_id = auth.user_org_id() AND auth.user_role() IN ('org_admin', 'org_user'))
    OR auth.is_super_admin()
  );

-- ============ AUTOMATIONS ============
CREATE POLICY "Org sees own automations" ON automations FOR SELECT
  USING (org_id = auth.user_org_id() OR auth.is_super_admin());

CREATE POLICY "Org admin manages automations" ON automations FOR ALL
  USING (
    (org_id = auth.user_org_id() AND auth.user_role() = 'org_admin')
    OR auth.is_super_admin()
  );

CREATE POLICY "Org sees own automation runs" ON automation_runs FOR SELECT
  USING (org_id = auth.user_org_id() OR auth.is_super_admin());

CREATE POLICY "System inserts runs" ON automation_runs FOR INSERT
  WITH CHECK (true);

-- ============ INBOX ============
CREATE POLICY "Org sees own inbox" ON inbox_emails FOR SELECT
  USING (org_id = auth.user_org_id() OR auth.is_super_admin());

CREATE POLICY "Org users manage inbox" ON inbox_emails FOR ALL
  USING (
    (org_id = auth.user_org_id() AND auth.user_role() IN ('org_admin', 'org_user'))
    OR auth.is_super_admin()
  );

-- ============ AUDIT LOG ============
CREATE POLICY "Org admin sees audit" ON audit_log FOR SELECT
  USING (
    (org_id = auth.user_org_id() AND auth.user_role() = 'org_admin')
    OR auth.is_super_admin()
  );

CREATE POLICY "System writes audit" ON audit_log FOR INSERT
  WITH CHECK (true);
