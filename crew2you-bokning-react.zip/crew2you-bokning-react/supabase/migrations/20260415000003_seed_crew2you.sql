-- ============================================================================
-- Seed: Crew2you initial organization and users
-- ============================================================================
-- This creates the Crew2you tenant and default automations.
-- USER ACCOUNTS are created separately via Supabase Auth (Magic Link)
-- and then linked to a profile via the handle_new_user trigger.
-- ============================================================================

-- ============ Crew2you organization ============
INSERT INTO organizations (id, name, org_number, address, settings)
VALUES (
  '11111111-1111-1111-1111-111111111111',
  'Crew2you Sverige AB',
  NULL, -- fill in real org number
  'Södertälje',
  '{"booking_email": "bokning@crew2you.se", "default_hourly_rate": 495, "default_personnel_rate": 180}'::jsonb
)
ON CONFLICT (id) DO NOTHING;

-- ============ Default automations for Crew2you ============
INSERT INTO automations (org_id, name, description, trigger_event, actions, enabled) VALUES
('11111111-1111-1111-1111-111111111111',
 'Bokningsbekräftelse till butik & kund',
 'När ett uppdrag flyttas till "Bekräftad" skickas automatiskt mail till butik + uppdragsgivare.',
 'booking.stage.bekraftad',
 '[{"type": "send_email", "to": "store_contact", "template": "booking_confirmation"}, {"type": "send_email", "to": "customer_contact", "template": "booking_confirmation"}]'::jsonb,
 true),

('11111111-1111-1111-1111-111111111111',
 'SMS + kalenderinvite till personal',
 'När personal tilldelas ett uppdrag skickas SMS och kalenderinvite.',
 'booking.personnel.assigned',
 '[{"type": "send_sms", "to": "personnel", "template": "assignment"}, {"type": "send_calendar_invite", "to": "personnel"}]'::jsonb,
 true),

('11111111-1111-1111-1111-111111111111',
 'Påminnelse-SMS 24h innan uppdrag',
 'Dagen innan uppdraget får demovärden ett SMS med påminnelse + checklista.',
 'booking.reminder.24h',
 '[{"type": "send_sms", "to": "personnel", "template": "reminder_24h"}]'::jsonb,
 true),

('11111111-1111-1111-1111-111111111111',
 'Återrapport till uppdragsgivare',
 'När personalen skickar in återrapport vidarebefordras den till uppdragsgivaren.',
 'booking.report.submitted',
 '[{"type": "send_email", "to": "customer_contact", "template": "report_forward"}]'::jsonb,
 true),

('11111111-1111-1111-1111-111111111111',
 'Fakturaunderlag till Fortnox',
 'När uppdrag markeras som återrapporterat skapas fakturaunderlag i Fortnox.',
 'booking.stage.aterrapporterad',
 '[{"type": "fortnox_create_draft", "include_expenses": true}]'::jsonb,
 true),

('11111111-1111-1111-1111-111111111111',
 'Slack-notis vid nya utlägg',
 'När ett utlägg registreras får kontoret en Slack-notis i #utlagg.',
 'expense.created',
 '[{"type": "slack_notify", "channel": "#utlagg"}]'::jsonb,
 true),

('11111111-1111-1111-1111-111111111111',
 'Veckorapport till uppdragsgivare',
 'Varje fredag 16:00 skickas en sammanfattning till alla uppdragsgivare.',
 'schedule.weekly.friday_16',
 '[{"type": "send_weekly_summary", "to": "all_active_customers"}]'::jsonb,
 false),

('11111111-1111-1111-1111-111111111111',
 'AI-matchning av personal',
 'När ett uppdrag saknar personal föreslår AI:n topp 3 demovärdar.',
 'booking.personnel.missing',
 '[{"type": "ai_match_personnel", "top_n": 3}]'::jsonb,
 true),

('11111111-1111-1111-1111-111111111111',
 'AI-parsning av bokningsmail',
 'Mail till bokning@crew2you.se läses av AI:n som extraherar uppdragsinfo.',
 'inbox.email.received',
 '[{"type": "ai_parse_email"}, {"type": "create_booking_or_request_info"}]'::jsonb,
 true);


-- ============ AUTO-CREATE USER PROFILE ON SIGNUP ============
-- Trigger: when auth.users gets a new row, create matching user_profile
-- bound to Crew2you (initial single-tenant). Adjust for multi-tenant signup later.

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  default_org_id UUID := '11111111-1111-1111-1111-111111111111';
  user_role_to_assign user_role := 'org_user';
  user_full_name TEXT;
BEGIN
  -- Assign super_admin to specific Samify emails
  IF NEW.email IN ('adnan@samify.se', 'rasmus@samify.se') THEN
    user_role_to_assign := 'super_admin';
  END IF;

  -- Pick name from metadata or fall back to email prefix
  user_full_name := COALESCE(
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'name',
    split_part(NEW.email, '@', 1)
  );

  INSERT INTO public.user_profiles (id, org_id, email, full_name, role)
  VALUES (NEW.id, default_org_id, NEW.email, user_full_name, user_role_to_assign)
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
